# Apache Directory Studio Puppet Module for Boxen

Requires the `boxen` puppet module.

## Usage

```puppet
include apachedirectorystudio
```

## Developing

Write code.

Run `script/cibuild`.
